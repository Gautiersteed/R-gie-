# Installation sur DigitalOcean — pas à pas

Encodeur de direct vers YouTube, hébergé sur un Droplet DigitalOcean.
Coût : **6 $/mois** (≈ 5,20 €), dont **~2 mois offerts** grâce au crédit de bienvenue de 200 $.

---

## 1. Créer le compte

1. Va sur **digitalocean.com** → *Sign up*.
2. Email + mot de passe (ou « Sign in with Google »).
3. Ajoute un moyen de paiement (carte bancaire). Le crédit de 200 $ (valable 60 jours) est appliqué automatiquement.
4. Vérifie ton email pour activer le compte.

---

## 2. Créer le Droplet — les réglages exacts

Bouton **Create → Droplets**. Réponds comme ceci :

| Étape | Choix à faire |
|---|---|
| **Region** | **Amsterdam — AMS3** (ou Frankfurt — FRA1) |
| **Choose an image** | Onglet **OS** → **Ubuntu 24.04 (LTS) x64** |
| **Droplet Type** | **Basic** |
| **CPU options** | **Regular** *(surtout pas Premium AMD/Intel, c'est plus cher)* |
| **Size** | **6 $/mo** → 1 vCPU · 1 GiB · **25 GiB SSD** · 1000 GiB transfer |
| **Additional options** | **IPv4 ✓** (déjà coché) · Monitoring ✓ (gratuit) · **Backups ✗** (+20 %) |
| **Authentication** | **Password** (le plus simple depuis le téléphone) |
| **Hostname** | `encodeur-live` |
| **Tags** | *facultatif* |
| **Quantity** | 1 |

→ **Create Droplet**. Il est prêt en ~50 secondes.

### Ce qu'il faut éviter
- **Premium AMD/Intel** → 7 $ au lieu de 6 $
- **Backups** → +20 % (≈ 1,20 $/mois), inutile ici : la sauvegarde, c'est ton code + ta vidéo
- **Block storage, Load balancer, Managed database** → hors de prix et inutiles
- Le Droplet à **4 $** (512 Mo, 10 Go) : trop juste pour ta vidéo de 11 h

### Ce que tu récupères
Une **adresse IPv4** du type `164.90.xxx.xxx`, et le mot de passe root **envoyé par email** (jetable, à changer).

---

## 3. Se connecter en SSH depuis le téléphone

**Méthode simple (aucune app) :** sur la page du Droplet → bouton **Console** → un terminal s'ouvre dans le navigateur. Identifiant `root`, mot de passe reçu par email (frappe-le au clavier virtuel ; il n'apparaît pas à l'écran).

**Méthode confortable (recommandée) :** installe **Termux** (Android) depuis F-Droid :

```bash
pkg update -y && pkg install -y openssh rsync
ssh root@164.90.xxx.xxx
```

Au premier login, change le mot de passe : `passwd`

---

## 4. Installer le serveur

Copie le script `install-vps.sh` sur le VPS (voir §5 pour le transfert), puis :

```bash
bash install-vps.sh
```

Il fait tout, dans l'ordre : mises à jour + **correctifs de sécurité automatiques**, ffmpeg,
Node 20, Caddy, 2 Go de swap, utilisateur applicatif, **service systemd** (redémarrage auto au
boot et après plantage), pare-feu, **fail2ban**, puis HTTPS + mot de passe si tu fournis un domaine.

### Avec HTTPS (recommandé)

1. Crée un sous-domaine gratuit sur **duckdns.org** (2 min) et pointe-le vers l'IPv4 du Droplet.
2. Lance :

```bash
DOMAINE=mon-encodeur.duckdns.org bash install-vps.sh
```

→ le script demande le mot de passe de la page, Caddy obtient le certificat, tu accèdes à
`https://mon-encodeur.duckdns.org` avec une protection par mot de passe.

### Sans domaine

```bash
bash install-vps.sh
```

→ accès par `http://IP:3000`. Le script ouvre le port 3000. Moins sûr : mets un mot de passe
dès que possible (retourne la question du §4 avec un domaine duckdns).

---

## 5. Envoyer l'encodeur

L'application pèse ~150 Ko. Trois façons, de la plus simple à la plus robuste.

### A. Depuis un ordinateur (le plus rapide)

```bash
rsync -avP ~/live-encoder/ root@IP_DU_VPS:/opt/live-encoder/
```

### B. Depuis le téléphone avec Termux

```bash
# envoie le dossier depuis le stockage du téléphone
rsync -avP ~/storage/downloads/live-encoder/ root@IP_DU_VPS:/opt/live-encoder/ -e ssh
```

### C. Via GitHub (pratique pour les mises à jour)

Pousse le dossier dans un dépôt, puis sur le VPS :

```bash
git clone https://github.com/TON_COMPTE/live-encoder.git /opt/live-encoder
```

---

## 6. Démarrer

Sur le VPS :

```bash
chown -R encodeur:encodeur /opt/live-encoder
bash deployer-encodeur.sh
```

Le script vérifie les fichiers, démarre le service et t'affiche l'URL d'accès + l'état du disque.

Ouvre l'URL sur ton téléphone → l'interface s'affiche. Tu peux l'ajouter à l'écran d'accueil
(menu du navigateur → « Ajouter à l'écran d'accueil ») : elle se comporte comme une app.

---

## 7. Envoyer une grosse vidéo (11 h ≈ 12,4 Go)

L'upload par navigateur échouera. Utilise rsync **avec reprise en cas de coupure** :

```bash
rsync -avP --append-verify ma-video-11h.mp4 root@IP_DU_VPS:/opt/live-encoder/data/clips/
```

Puis dans l'app, onglet **Clips** → champ **« …ou un fichier déjà sur le serveur »** :

```
data/clips/ma-video-11h.mp4
```

L'app lit les métadonnées et indique si la **lecture directe** s'applique (H.264/AAC = aucun
ré-encodage, aucun cache, 0 % de CPU).

### Réglages recommandés pour une vidéo de 11 h

| Réglage | Valeur |
|---|---|
| Format | 16:9 (ou 9:16 pour du vertical) |
| Qualité | 720p · 30 i/s · **2500 kb/s** → ≈ 12,4 Go |
| « Nouveau direct toutes les… » | **Jamais** (le clip finit avant la limite de 12 h) |
| Relance automatique | **2 minutes** |

---

## 8. Vérifier à tout moment

```bash
bash verifier-vps.sh
```

Contrôle : système, mémoire, **disque (% utilisé)**, ffmpeg/node/caddy, état du service,
réponse HTTP, et surtout **la joignabilité de YouTube en RTMP** — si ce test échoue, aucune
diffusion ne partira.

Journaux en direct :

```bash
journalctl -u live-encoder -f
```

---

## 9. À savoir

- **Trafic** : 1 To/mois inclus. À 2500 kb/s en continu tu consommes ~810 Go → OK.
  En 1080p (4 500 kb/s) tu dépasserais (+0,01 $/Go).
- **Disque** : 25 Go. Système ~2,5 Go + vidéo 12,4 Go = ~15 Go. Garde ~4 Go libres.
- **Redémarrage du serveur** : le service repart tout seul, mais pas la diffusion en cours —
  relance-la depuis l'app (ou programme-la).
- **Mises à jour de sécurité** : `unattended-upgrades` est activé par le script.
- **Mot de passe SSH** : active une clé SSH et désactive l'authentification par mot de passe
  dès que tu es à l'aise (`PasswordAuthentication no` dans `/etc/ssh/sshd_config`).

---

## Récapitulatif des fichiers

| Fichier | Où | Rôle |
|---|---|---|
| `install-vps.sh` | sur le VPS | installe tout le serveur (à lancer en premier) |
| `deployer-encodeur.sh` | sur le VPS | vérifie les fichiers, démarre le service |
| `verifier-vps.sh` | sur le VPS | diagnostic complet |
| `server.js`, `public/` | `/opt/live-encoder/` | l'application |
