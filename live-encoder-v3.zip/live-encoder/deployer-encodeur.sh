#!/usr/bin/env bash
# ============================================================
#  deployer-encodeur.sh — à lancer SUR le VPS, après avoir copié l'encodeur
#  Vérifie les fichiers, démarre le service, affiche l'état.
#  Usage :  sudo bash deployer-encodeur.sh
# ============================================================
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/live-encoder}"
UTILISATEUR="${UTILISATEUR:-encodeur}"
PORT="${PORT:-3000}"

echo "==> Vérification des fichiers"
for f in server.js public/index.html; do
  if [ ! -f "$APP_DIR/$f" ]; then
    echo "  ✗ manquant : $APP_DIR/$f"
    echo
    echo "Copie d'abord l'encodeur depuis ton ordinateur :"
    echo "  rsync -avP ~/live-encoder/ root@<ip-du-vps>:$APP_DIR/"
    exit 1
  fi
  echo "  ✓ $APP_DIR/$f"
done

mkdir -p "$APP_DIR"/{data/clips,data/cache,recordings,public}
chown -R "$UTILISATEUR:$UTILISATEUR" "$APP_DIR"
chmod 750 "$APP_DIR"

echo "==> Démarrage du service"
systemctl restart live-encoder
sleep 4

if systemctl is-active --quiet live-encoder; then
  echo "  ✓ service actif"
else
  echo "  ✗ le service n'a pas démarré. Journaux :"
  journalctl -u live-encoder -n 30 --no-pager
  exit 1
fi

echo "==> Test de réponse"
CODE=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PORT/" || echo 000)
echo "  HTTP $CODE sur 127.0.0.1:$PORT"

echo "==> Outils"
ffmpeg -version 2>/dev/null | head -1 | sed 's/^/  /'
node -v | sed 's/^/  node /'

echo "==> Disque"
TOTAL=$(df --output=size -h / | tail -1 | tr -d ' ')
DISPO=$(df --output=avail -h / | tail -1 | tr -d ' ')
PCT=$(df --output=pcent / | tail -1 | tr -d ' %')
echo "  $DISPO libres sur $TOTAL (utilisé à $PCT %)"
if [ "$PCT" -ge 80 ]; then
  echo "  ⚠️  Disque bien rempli : pense à supprimer d'anciens clips."
fi

IPV4=$(curl -4 -s --max-time 5 https://ifconfig.me || echo "<ip-du-vps>")
echo
echo "============================================================"
echo " Encodeur en ligne :  http://$IPV4:$PORT"
echo " (ou https://<ton-domaine> si Caddy est configuré)"
echo
echo " Journaux en direct :  journalctl -u live-encoder -f"
echo " ============================================================"
