#!/usr/bin/env bash
# ============================================================
#  Live Encoder — installation sur VPS IPv4 (DigitalOcean, OVH, Scaleway…)
#  Ubuntu 24.04 / Debian 12
#
#  Usage :
#     DOMAINE=mon-encodeur.duckdns.org bash install-vps.sh
#     (sans DOMAINE, la page reste en HTTP simple sur le port 3000)
# ============================================================
set -euo pipefail

DOMAINE="${DOMAINE:-}"
APP_DIR="/opt/live-encoder"
UTILISATEUR="encodeur"

echo "==> 1/8 · Mise à jour + correctifs de sécurité automatiques"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get upgrade -y -qq
apt-get install -y -qq unattended-upgrades >/dev/null
dpkg-reconfigure -f noninteractive unattended-upgrades >/dev/null 2>&1 || true

echo "==> 2/8 · Paquets (ffmpeg, node, caddy, rsync, ufw, fail2ban)"
apt-get install -y -qq ffmpeg curl ca-certificates gnupg rsync ufw fail2ban unzip >/dev/null

if ! command -v node >/dev/null || [ "$(node -v | tr -d 'v' | cut -d. -f1)" -lt 18 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs >/dev/null
fi

if ! command -v caddy >/dev/null; then
  apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https >/dev/null
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
    | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
    | tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  apt-get update -qq
  apt-get install -y -qq caddy >/dev/null
fi

echo "==> 3/8 · Swap 2 Go"
if [ ! -f /swapfile ]; then
  fallocate -l 2G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile >/dev/null
  swapon /swapfile
  grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

echo "==> 4/8 · Utilisateur applicatif + dossiers"
id -u "$UTILISATEUR" >/dev/null 2>&1 || useradd -r -m -d "/home/$UTILISATEUR" -s /bin/bash "$UTILISATEUR"
mkdir -p "$APP_DIR"/{data/clips,data/cache,recordings,public}
chown -R "$UTILISATEUR:$UTILISATEUR" "$APP_DIR"

echo "==> 5/8 · Service systemd (redémarre au boot et après plantage)"
cat >/etc/systemd/system/live-encoder.service <<UNIT
[Unit]
Description=Live Encoder (diffusion RTMP vers YouTube)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$UTILISATEUR
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
Environment=NODE_ENV=production
# Mot de passe de la page : définis ENCODER_PASSWORD ci-dessous, ou laisse
# l'encodeur en générer un au premier démarrage (affiché dans les journaux).
# Environment=ENCODER_PASSWORD=monmotdepasse

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable live-encoder >/dev/null 2>&1 || true

echo "==> 6/8 · Pare-feu + fail2ban"
ufw allow OpenSSH >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
yes | ufw enable >/dev/null || true
systemctl enable --now fail2ban >/dev/null 2>&1 || true

echo "==> 7/8 · Caddy (HTTPS + mot de passe)"
if [ -n "$DOMAINE" ]; then
  echo
  echo "Mot de passe de la page web (utilisateur : gautier) :"
  read -rs MOTDEPASSE
  echo
  HASH=$(caddy hash-password --plaintext "$MOTDEPASSE")
  cat >/etc/caddy/Caddyfile <<CADDY
$DOMAINE {
    basicauth {
        gautier $HASH
    }
    reverse_proxy 127.0.0.1:3000
}
CADDY
  systemctl reload caddy 2>/dev/null || systemctl restart caddy
  echo "    → https://$DOMAINE"
else
  echo "    (aucun domaine fourni : accès par http://IP:3000 — mets un mot de passe)"
  ufw allow 3000/tcp >/dev/null
fi

echo "==> 8/8 · État du disque"
df -h / | sed -n '1p;$p'

IPV4=$(curl -4 -s --max-time 5 https://ifconfig.me || echo "?")
echo
echo "============================================================"
echo " Serveur prêt · IPv4 : $IPV4"
echo
echo " 1. Copie l'encodeur depuis TON ordinateur :"
echo "      rsync -avP ~/live-encoder/ root@$IPV4:$APP_DIR/"
echo
echo " 2. Puis sur le serveur :"
echo "      chown -R $UTILISATEUR:$UTILISATEUR $APP_DIR"
echo "      systemctl start live-encoder"
echo "      systemctl status live-encoder --no-pager"
echo
echo " 3. Gros fichiers : envoie-les dans $APP_DIR/data/clips/"
echo "    puis déclare-les dans l'onglet Clips (champ « fichier déjà sur le serveur »)."
echo "============================================================"
