#!/usr/bin/env bash
# ============================================================
#  verifier-vps.sh — diagnostic rapide, à lancer SUR le VPS
#  Usage :  sudo bash verifier-vps.sh
# ============================================================
set -uo pipefail
APP_DIR="${APP_DIR:-/opt/live-encoder}"
PORT="${PORT:-3000}"

ok()   { echo "  ✓ $*"; }
ko()   { echo "  ✗ $*"; }
warn() { echo "  ⚠ $*"; }

echo "── Système ──────────────────────────────"
. /etc/os-release 2>/dev/null && ok "$PRETTY_NAME"
ok "noyau $(uname -r)"
uptime | sed 's/^/  /'

echo
echo "── Mémoire ──────────────────────────────"
free -h | sed -n '1,3p' | sed 's/^/  /'

echo
echo "── Disque ───────────────────────────────"
PCT=$(df --output=pcent / | tail -1 | tr -d ' %')
df -h / | sed -n '1p;$p' | sed 's/^/  /'
if [ "$PCT" -ge 80 ]; then warn "utilisé à $PCT % — libère de la place"
elif [ "$PCT" -ge 60 ]; then warn "utilisé à $PCT % — surveille"
else ok "utilisé à $PCT %"; fi
echo "  Clips : $(du -sh "$APP_DIR/data/clips" 2>/dev/null | cut -f1)"
echo "  Cache : $(du -sh "$APP_DIR/data/cache" 2>/dev/null | cut -f1)"

echo
echo "── Outils ───────────────────────────────"
command -v ffmpeg >/dev/null && ok "ffmpeg $(ffmpeg -version | head -1 | awk '{print $3}')" || ko "ffmpeg absent"
command -v node   >/dev/null && ok "node $(node -v)" || ko "node absent"
command -v caddy  >/dev/null && ok "caddy $(caddy version | head -1)" || warn "caddy absent (pas de HTTPS)"
[ -x "$APP_DIR/bin/yt-dlp" ] && ok "yt-dlp local" || warn "yt-dlp pas encore téléchargé (auto à la 1re utilisation)"

echo
echo "── Service ──────────────────────────────"
if systemctl is-active --quiet live-encoder; then ok "live-encoder actif"; else ko "live-encoder arrêté"; fi
systemctl is-enabled --quiet live-encoder 2>/dev/null && ok "démarrage auto au reboot" || warn "pas activé au boot"

echo
echo "── Réseau ───────────────────────────────"
CODE=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PORT/" || echo 000)
[ "$CODE" = "200" ] && ok "répond en HTTP $CODE sur 127.0.0.1:$PORT" || ko "pas de réponse sur le port $PORT (HTTP $CODE)"
ss -lntp 2>/dev/null | grep -q ":$PORT " && ok "port $PORT en écoute" || warn "rien n'écoute sur $PORT"
IPV4=$(curl -4 -s --max-time 5 https://ifconfig.me || echo "?")
ok "IPv4 publique : $IPV4"
timeout 5 bash -c "cat < /dev/null > /dev/tcp/a.rtmp.youtube.com/1935" 2>/dev/null \
  && ok "YouTube RTMP joignable (a.rtmp.youtube.com:1935)" \
  || ko "YouTube RTMP INJOIGNABLE — le direct ne partira pas"

echo
echo "── Derniers journaux ────────────────────"
journalctl -u live-encoder -n 8 --no-pager --output=cat 2>/dev/null | sed 's/^/  /'
