# Live Encoder · YouTube — v3 (fusionnée avec la Régie)

La page réunit désormais **deux outils dans une seule interface à 6 onglets** :

| Onglet | Rôle | Serveur requis |
|---|---|---|
| **Régie** | lecteur YouTube, chat en direct, connexion Google (OAuth), horaires du direct | non |
| **Direct** | encodeur caméra (pop-up d'autorisation, journal d'erreurs, arrêt auto) | oui |
| **Clips** | upload / lien, découpe début-fin, boucle, diffusion autonome, programmation | oui |
| **Réglages** | débits, équivalents OBS, état des autorisations, commande FFmpeg | — |
| **Mobile**, **Aide** | guides | — |

> La page détecte le contexte : hébergée seule (GitHub Pages), la **Régie** fonctionne et le pop-up
> caméra ne s'affiche pas ; servie par `server.js`, tout fonctionne. Le même fichier sert aux deux cas.

---

# Historique


Encodeur de direct maison, pilotable depuis un téléphone.
**Deux moteurs**, selon que tu veux filmer ou diffuser un clip préparé.

| Mode | Qui diffuse | Écran éteint / téléphone en veille / réseau coupé |
|---|---|---|
| **Caméra** | le téléphone (via le serveur) | ❌ impossible : le flux part de l'appareil |
| **Clips** | **le serveur seul** | ✅ le direct continue |

> ⚠️ **Précision importante** : sans internet, *aucune* diffusion vers YouTube n'est possible —
> YouTube doit recevoir le flux. Ce que la v2 permet, c'est de **déporter la diffusion sur le
> serveur** : ton téléphone ne sert qu'à lancer. Tu peux ensuite verrouiller l'écran, l'éteindre,
> le mettre en poche ou perdre le réseau : le serveur continue d'émettre jusqu'à l'heure de fin.

---

## Démarrage

```bash
cd live-encoder
node server.js
# → http://localhost:3000
```

Aucune dépendance npm. Au premier lancement le serveur installe tout seul :
**FFmpeg** (apt) et **yt-dlp** (pip ou binaire statique) si absents. Node 18+.

L'accès à la caméra exige un contexte sécurisé : `localhost`, ou HTTPS via un tunnel
(`cloudflared tunnel --url http://localhost:3000`). L'onglet **Clips** n'a pas cette contrainte.

---

## Onglet Clips — mode autonome

1. **Ajouter un clip** : choix d'un fichier (MP4, MOV, MKV, WebM) ou **lien vidéo** (téléchargé par le serveur).
2. **Découper** : champ *Début* et *Fin* en secondes, avec aperçu du passage retenu.
3. **Boucler** : case *Répéter en boucle*.
4. **Diffuser** (immédiat) ou **Planifier** : heure de début + fin par durée ou par heure.

### Ce qui se passe côté serveur

Le clip est **préparé une seule fois** puis mis en cache : extraction du passage début→fin,
ré-encodage aux réglages YouTube (ou silence ajouté si le clip est muet), keyframes toutes les 2 s.
La diffusion réelle se fait ensuite en `-c copy` : le serveur ne pousse que des octets, donc
**CPU quasi nul**, aucune dérive de qualité, et une boucle sans coupure visible.

L'état de diffusion est persisté (heure de fin, clip, clé) :
**si le serveur redémarre en cours de direct, la diffusion reprend automatiquement** et
l'heure de fin d'origine est respectée.

---

## Réglages d'encodage (préparation des clips et mode caméra)

| Paramètre | Valeur |
|---|---|
| Vidéo | H.264 (libx264), profil High, `yuv420p` |
| Audio | AAC-LC, 44,1 kHz, stéréo, 128 kb/s |
| Keyframes | toutes les 2 s (`-g 2×fps -sc_threshold 0`) |
| Débits | 1080p30 : 4500 · 720p60 : 3500 · 720p30 : 2500 · 480p30 : 1000 · 360p30 : 600 kb/s |
| Sortie | FLV sur RTMP / RTMPS |

---

## Thème clair (fond blanc)

Toute l'interface est en **fond blanc sur les 6 onglets**, y compris les cadres vidéo, les modales,
le journal, la zone de commande FFmpeg et les notifications. Palette centralisée dans `:root` :

```css
--bg:#ffffff; --panel:#ffffff; --panel2:#f8fafc;
--line:#e2e8f0; --txt:#0f172a; --txt-muted:#334155; --dim:#64748b;
--accent:#ff2d55; --accent2:#0284c7;
--ok:#16a34a; --warn:#b45309; --err:#dc2626;
```

Contrôle automatisé : un scan de tous les éléments de la page détecte les surfaces sombres
opaque > 2000 px² — résultat attendu et obtenu : **aucune**.

## Accès protégé par mot de passe

L'application est **verrouillée par défaut** : sans le mot de passe, impossible de voir la page,
de lancer/arrêter un direct, ni de lire un fichier.

### Comment le mot de passe est choisi

| Situation | Ce qui se passe |
|---|---|
| Variable `ENCODER_PASSWORD` définie | Ce mot de passe est utilisé (prioritaire) |
| `data/auth.json` existe | Le mot de passe enregistré est utilisé |
| Premier démarrage, sinon | Un **code à 6 chiffres est généré** et affiché dans le journal, puis enregistré |

```bash
journalctl -u live-encoder -n 40 --no-pager | grep -A6 "MOT DE PASSE"
```

Pour fixer le mot de passe dans le service :

```bash
systemctl edit live-encoder
# puis dans l'éditeur :
[Service]
Environment=ENCODER_PASSWORD=monmotdepasse
```
Puis `systemctl restart live-encoder`.

### Ce qui est protégé

- toutes les pages et tous les fichiers (vidéos, enregistrements) ;
- toutes les routes `/api/*` ;
- le **WebSocket** `/ws` (caméra + changements d'état).

Un appel direct à l'API sans session renvoie `401` : impossible de piloter l'encodeur en
devinant l'URL.

### Détails techniques

- Mot de passe haché avec **scrypt** (jamais stocké en clair), comparaison à temps constant.
- Session par **cookie `HttpOnly`, `SameSite=Strict`**, marqué `Secure` dès que la page est en HTTPS, valable 7 jours et prolongé à chaque usage.
- **Anti-bruteforce** : 6 essais ratés depuis une même adresse → blocage 10 minutes (`429`).
- Changer le mot de passe **déconnecte toutes les autres sessions**.
- Bouton **« Verrouiller maintenant »** (onglet Réglages) pour quitter les lieux sans fermer le direct.

### Si tu oublies le mot de passe

```bash
sudo rm /opt/live-encoder/data/auth.json
sudo systemctl restart live-encoder
journalctl -u live-encoder -n 40 --no-pager | grep -A6 "MOT DE PASSE"
```
Un nouveau code est généré.

## Diffuser une très longue vidéo (11 h)

Une vidéo de 11 h **passe sur l'offre à 1 €**, à trois conditions.

### 1. Ne pas la ré-encoder

À 2,5 Mbps, 11 h pèsent **~12,4 Go**. Si l'encodeur la ré-encodait, il créerait un fichier de cache
supplémentaire de 12 Go sur 20 Go de disque — impossible. D'où la **lecture directe** :

- si la source est déjà **H.264 + AAC**, jusqu'à **1920 px**, sans découpe demandée
  → le fichier est diffusé tel quel (`-c copy`), **0 % de CPU, 0 Go de cache** ;
- sinon, ré-encodage classique (à éviter pour les vidéos de cette taille).

Le journal indique lequel des deux cas s'applique :
`Lecture directe de « … » (h264/aac, 1280×720) : aucun ré-encodage, aucun fichier temporaire.`

### 2. Transférer le fichier sans passer par l'interface

Un envoi de 12 Go par le navigateur échoue presque toujours (mémoire du téléphone, coupures).
Utilise **rsync/scp**, puis déclare le fichier dans l'onglet Clips
(champ « …ou un fichier déjà sur le serveur », API `POST /api/clips/adopt`) :

```bash
rsync -avP --append-verify ma-video-11h.mp4 root@mon-vps:/opt/live-encoder/data/clips/
```

### 3. Découper, puis laisser la relance enchaîner

Une vidéo de 11 h = **un direct de 11 h**, juste sous la limite des 12 h. Cycle recommandé :

| Étape | Réglage |
|---|---|
| Durée du clip | 11 h |
| « Nouveau direct toutes les… » | **Jamais** (le clip finit avant la limite) |
| Relance automatique | **2 min** |

Le clip se termine → YouTube archive le direct → 2 min plus tard un **nouveau direct** démarre.
L'encodeur détecte d'ailleurs le cas : il n'ajoute pas de recyclage inutile
(`Recyclage ignoré : le clip dure déjà 11:00`).

Le disque reste ainsi à ~12,5 Go sur 20 Go (12,4 Go de source + l'overlay système).

## Relance automatique (boucle jusqu'à « Tout arrêter »)

Carte **Relance automatique** présente dans l'onglet **Direct** et dans l'onglet **Clips** :

- case à cocher **« Relancer la diffusion quand elle s'arrête »** (activée par défaut) ;
- **délai** réglable : 30 s, 1 min, **2 min (par défaut)**, 5 min, 10 min ;
- compteur des relances enchaînées et heure de la prochaine relance ;
- **bandeau flottant sur toutes les pages** avec le compte à rebours et un bouton **Tout arrêter**.

Fonctionne dans les deux modes :

| Situation | Comportement |
|---|---|
| Clip terminé (sans boucle) | attente du délai, puis relance du même clip |
| Clip en boucle | pas de coupure, la boucle FFmpeg continue |
| Coupure FFmpeg en mode caméra | relance automatique après le délai |
| Arrêt manuel / heure de fin programmée | **la boucle s'arrête** (consigne explicite) |
| « Tout arrêter » | arrête la diffusion **et** désactive la relance |

API : `POST /api/live/autorestart` avec `{"enabled":true,"delaySec":120}`.
Garde-fou : maximum 1000 relances enchaînées.


### Nouveau direct toutes les X heures (recyclage)

YouTube **ne conserve pas l'enregistrement d'une diffusion de plus de 12 h** : le replay n'existe pas
et les heures de visionnage ne comptent pas. Pour un flux permanent, l'encodeur **coupe donc
volontairement le flux avant la limite** et enchaîne sur un nouveau direct.

- Réglage **« Nouveau direct toutes les… »** dans les deux cartes : Jamais, 5 h 30, **11 h (défaut)**, 12 h, 23 h (+ 30 s / 1 min 30 / 3 min pour les tests).
- Le compte à rebours du prochain direct s'affiche dans la carte et dans le bandeau flottant.
- Bouton **« Nouveau direct maintenant »** pour couper tout de suite.
- La coupure est propre (SIGINT → FFmpeg vide son tampon) puis la relance automatique repart, avec le délai configuré.
- Compteur de **recyclages** dans la carte.
- Un arrêt manuel / « Tout arrêter » coupe aussi le recyclage.

Côté YouTube, deux conditions pour que le direct reparte seul :

1. **Clé de flux réutilisable** — case « Clé de flux réutilisable » dans la carte de création
   (`contentDetails.isReusable: true`). À chaque reconnexion, YouTube ouvre alors un **nouveau direct**
   sans changer la clé.
2. **Auto-start / auto-stop activés** (cochés par défaut) pour que le direct passe en ligne tout seul
   quand le flux revient.

API : `POST /api/live/recycle` (recyclage immédiat) et `recycleMin` accepté par
`POST /api/live/autorestart`.

## Créer un direct depuis l'app (sans YouTube Studio)

Onglet **Régie → carte « Créer un direct »**. Un seul formulaire remplace tout Studio :

| Champ | Effet |
|---|---|
| Titre, description, catégorie | `snippet` du direct |
| Confidentialité (public / non répertorié / privé) | `status.privacyStatus` |
| Contenu pour enfants | `status.selfDeclaredMadeForKids` |
| Format (16:9, 9:16, 1:1, 4:5) | appliqué à l'encodage (recadrage centré) |
| Auto-start / auto-stop | le direct passe en ligne dès le flux reçu |
| DVR / enregistrement | `enableDvr`, `recordFromStart` |
| Latence (normale / faible / très faible) | `latencyPreference` |
| Début prévu | `scheduledStartTime` |

Enchaînement API exécuté :

```
POST liveBroadcasts             → crée le direct
POST liveStreams                → crée le flux + génère la clé
POST liveBroadcasts/bind        → lie le direct au flux
```

Le bouton **« Utiliser dans l'encodeur »** installe la clé et le format, puis bascule sur l'onglet
Direct : il ne reste qu'à cliquer sur *Démarrer le direct*.

## Formats d'image (16:9 · 9:16 · 1:1 · 4:5)

Disponible dans l'onglet **Direct** et dans l'onglet **Clips**. Le traitement est un
**recadrage centré** (`scale … force_original_aspect_ratio=increase` puis `crop`) : l'image
remplit le cadre sans bandes noires ni déformation.

| Format | Dimensions produites (qualité 720 / 1080) | Usage |
|---|---|---|
| 16:9 | 1280×720 / 1920×1080 | horizontal classique |
| **9:16** | **720×1280 / 1080×1920** | **vertical « Shorts / fil mobile »** |
| 1:1 | 720×720 / 1080×1080 | carré |
| 4:5 | 720×900 / 1080×1350 | portrait de fil |

> Le format dépend de ce que le **téléphone envoie** : pour du vertical, la caméra doit être
> tenue en portrait (ou le clip source déjà vertical). Un 16:9 recadré en 9:16 perd les côtés.

## Fusion avec la Régie (`gautiersteed.github.io/R-gie-`)

Le code de la page « Régie Mobile » (lecteur, chat, OAuth Google, horaires de direct) a été
intégré dans l'onglet **Régie**, sans perte de fonctionnalité :

- lecteur `youtube.com/embed` + chat `live_chat` (domaine pré-rempli depuis `location.hostname`) ;
- OAuth 2.0 « token model » (`gsi/client`) avec le scope `youtube.force-ssl` ;
- « Vérifier mon direct » et « Enregistrer les horaires » (PUT `liveBroadcasts` part `snippet`).

### Corrections apportées à la version d'origine

| Problème | Correction |
|---|---|
| Aucun journal d'erreurs persistant (un seul champ écrasé à chaque message) | les messages de la Régie alimentent le **Journal d'erreurs** commun (horodaté, copiable, conservé) |
| Erreur CORS/OAuth opaque | message explicite : *« autorise l'origine `…` dans Google Cloud → Origines JavaScript autorisées »* |
| `client_id` figé dans le HTML | même valeur par défaut, mais déplacée en JS et modifiable + mémorisée |
| Erreur `gsi` affichée par `log()` global fragile | gestionnaire dédié, l'interface continue de fonctionner sans Google |
| Page non testée sur mobile | interface mobile-first, 4 onglets → 6 onglets |

### ⚠️ À propos de la « clé »

L'**ID client OAuth** (`963550044765-…apps.googleusercontent.com`) est public par nature, il n'y a
donc aucun secret à protéger dans la page. En revanche :

- ne colle **jamais** le *secret client* dans le HTML ;
- restreins les **Origines JavaScript autorisées** à `https://gautiersteed.github.io` ;
- la **clé de flux YouTube** (`xxxx-xxxx-…`) est un vrai secret : elle se saisit dans l'onglet Direct
  et n'est jamais écrite dans le fichier.

## Structure

| Chemin | Rôle |
|---|---|
| `server.js` | HTTP + WebSocket + FFmpeg + moteur de clips + planificateur |
| `public/index.html` | Interface 6 onglets (servie par `server.js`) |
| `gh-pages/index.html` | **Copie à pousser sur GitHub Pages** (Régie seule, sans serveur) |
| `test-client.js` | Client de test (rejoue un WebM vers le serveur, sans navigateur) |
| `clips/` | Vidéos sources (upload et téléchargements) |
| `data/clips.json` | Bibliothèque : titres, points début/fin, boucle |
| `data/state.json` | Diffusion en cours (reprise après redémarrage), `chmod 600` |
| `data/cache/` | Clips préparés pour la diffusion (purgés après 7 jours) |
| `data/cookies.txt` | *Facultatif* — voir « YouTube bloque » ci-dessous |
| `bin/` | Binaires installés automatiquement (yt-dlp) |
| `recordings/` | Sorties du mode test |

---

## API (si tu veux piloter autrement)

```
GET    /api/clips                  bibliothèque + état
POST   /api/clips/upload           corps = fichier brut
POST   /api/clips/link             {"url": "…"}
PATCH  /api/clips/:id              {"start":4,"end":11,"loop":true,"title":"…"}
DELETE /api/clips/:id
POST   /api/live/start-clip        {"clipId","streamKey","preset","durationMin"|"untilTs"|"startAt"}
POST   /api/live/stop
GET    /api/live/state
```

---

## Autorisations caméra / micro

Au premier chargement, une **fenêtre de demande d'autorisation** s'affiche avec l'état réel
de chaque permission (accordée / à demander / refusée). Elle ne revient pas à chaque
rechargement (mémorisée pour la session) ; un bouton **Autoriser caméra et micro** reste
visible sur l'aperçu tant que l'accès manque.

Si l'accès est refusé, la fenêtre explique **où réactiver** l'autorisation selon le navigateur,
et le mode **Clips** reste utilisable (aucune caméra nécessaire).

---

## Journal d'erreurs

Carte **Journal d'erreurs** dans l'onglet Direct : erreurs du navigateur (permissions,
périphériques), du serveur, de FFmpeg (refus RTMP de YouTube), du réseau et des uploads.
Chaque entrée est horodatée et étiquetée par source, **conservée après rechargement**
(`localStorage`, 60 dernières entrées), avec **Copier** et **Vider**.

---

## Début et fin de diffusion manuels

Deux endroits, avec le même sélecteur **Aucun / Durée / Heure** :

- **Onglet Direct → carte « Début et fin de diffusion »** : arrêt automatique du direct caméra
  (durée en minutes ou heure précise). Le serveur coupe même si l'écran est éteint.
- **Onglet Clips → carte « Programmer une diffusion »** : choix du clip, heure de début
  (`datetime-local`) et fin par durée ou heure absolue. La planification en attente est
  affichée et annulable via le bouton d'arrêt.

---

## Héberger la page sans serveur (GitHub Pages)

C'est un **hébergement statique** : aucun serveur ne peut y exécuter FFmpeg. Conséquences :

| Fonction | GitHub Pages seul | Avec `node server.js` |
|---|---|---|
| Régie (lecteur, chat, OAuth, horaires) | ✅ | ✅ |
| Encodeur caméra | ❌ | ✅ |
| Upload de clips, ajout par lien | ❌ | ✅ |
| Diffusion / planification | ❌ | ✅ |

La page le détecte et affiche un bandeau **« Fonctions serveur indisponibles »** ; les commandes
concernées sont désactivées au lieu d'échouer silencieusement. Le journal n'inscrit **qu'une seule**
entrée réseau (avec un compteur `×N`) puis passe en veille longue : plus de bruit toutes les 6 s.

## Serveur injoignable / « Hors ligne »

L'interface affiche **Serveur injoignable** quand le processus n'écoute pas sur le port 3000.
C'est le cas le plus fréquent : l'espace de travail redémarre, et les processus longue durée
ne survivent pas. Relance simplement :

```bash
cd live-encoder && node server.js
```

Le bouton **Réessayer la connexion** retente sans recharger la page.

**Transport automatique** : l'interface utilise le WebSocket, et bascule d'elle-même en
**HTTP** (interrogation de l'état + envoi des morceaux en POST) si le WebSocket est bloqué
par un proxy, un réseau d'entreprise ou une iframe d'aperçu. Les deux transports sont testés
et fonctionnent à l'identique pour la caméra comme pour les clips.

---

## Problèmes connus et solutions

**YouTube bloque le téléchargement par lien (HTTP 429 « Too Many Requests »)**
Les IP de datacenter et de VPN sont filtrées par YouTube. Solutions : télécharger la vidéo
depuis ton téléphone ou ton PC puis l'**uploader** (aucune limite), ou exporter les cookies
d'un navigateur connecté vers `data/cookies.txt` (le serveur les utilise automatiquement).

**yt-dlp : « No supported JavaScript runtime could be found »**
Depuis 2026 l'extraction YouTube exige un runtime JS. Le serveur passe déjà
`--js-runtimes deno --js-runtimes node` ; installe Node récent ou `deno` sur la machine.

**Le direct coupe au bout de quelques minutes**
YouTube exige des keyframes régulières et un débit stable. Les clips préparés respectent
`-g 2×fps`. En mode caméra, descends d'un cran de qualité (720p → 480p).

**Caméra refusée sur le téléphone**
Contexte non sécurisé (`http://192.168…`) ou navigateur trop ancien. Utilise un tunnel HTTPS.
Le mode Clips, lui, fonctionne sans caméra.

**Arrêter une diffusion**
Bouton *Arrêter la diffusion* sur la carte « En direct », ou `POST /api/live/stop`.
Une planification en attente est annulée par le même bouton.

---

## Tests effectués (tous rejoués en local)

- Upload → découpe 5 s→12 s → boucle → diffusion : ✅ (fichier de 10 s pour une fenêtre de 7 s)
- Flux RTMP réel (récepteur local simulant YouTube) : H.264 1280×720 + AAC, 17 s continus en boucle ✅
- Clip **sans piste audio** : piste AAC silencieuse injectée, flux accepté ✅
- Arrêt automatique à l'heure de fin ✅
- **Redémarrage du serveur en pleine diffusion** : reprise auto + heure de fin d'origine ✅
- Arrêt manuel d'un clip en boucle : plus de relance fantôme ✅
- Démarrage planifié (timer) ✅
- Ajout par lien (yt-dlp auto-installé) ✅ — YouTube refuse les IP de datacenter, voir ci-dessus
- Interface testée dans Chromium mobile (400×900) : aucune erreur console ✅
- Fusion Régie : lecteur et chat chargés, 6 onglets fonctionnels, journal commun alimenté ✅
- Page hébergée sans serveur : Régie opérationnelle, pop-up explicatif, upload désactivé ✅
- Anti-spam du journal : 1 entrée (`×N`) au lieu de 20+ en 40 s ✅
- Diagnostic Régie : distingue « mauvais ID » et « vidéo qui n'est pas un direct » via `videos.list` ✅
- Création de direct (API simulée) : 3 appels corrects, tous les champs transmis, clé installée ✅
- Format 9:16 de bout en bout : source 1280×720 → sortie **720×1280** H.264 + AAC ✅
- Thème clair : scan des 6 onglets → **0 surface sombre**, encodage toujours fonctionnel ✅
- Relance automatique en mode clip (délai 5 s) : 4 relances enchaînées observées ✅
- Relance après coupure FFmpeg en mode caméra ✅
- Authentification : page, API, fichiers et WebSocket verrouillés ; 6 essais ratés → 429 ; verrouillage/déverrouillage depuis l'UI ✅
- « Tout arrêter » : plus aucune relance, `auto.enabled=false` côté serveur ✅
- Recyclage (délai de test 1 min) : coupure propre → nouveau direct → relance, journal sans répétition ✅
- Modale d'autorisation : affichage, états réels des permissions, refus → consignes + journal ✅
- Journal d'erreurs : alimentation multi-sources et persistance après rechargement ✅
- Arrêt automatique du mode caméra (durée) piloté par le serveur ✅
- Programmation clip : début + fin par durée **ou** heure ✅

## Sécurité

- La clé de flux n'est **jamais journalisée** (`rtmp://…/live2/••••••••`).
- Elle est mémorisée en `localStorage` sur le téléphone (case décochable) et, pour permettre la
  reprise après redémarrage, dans `data/state.json` en `chmod 600`.
- Le serveur n'a pas d'authentification : ne l'expose pas sur Internet sans HTTPS + mot de passe
  (tunnel, reverse proxy).
