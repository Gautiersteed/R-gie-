// Client de test : simule le navigateur (WS + chunks WebM) -> serveur -> RTMP
'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');

const [,, file, ingest, key, secondsStr] = process.argv;
const SECONDS = Number(secondsStr || 8);
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function connect(cb) {
  const req = http.request({
    host: '127.0.0.1', port: 3000, path: '/ws',
    headers: { Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Key': crypto.randomBytes(16).toString('base64'), 'Sec-WebSocket-Version': '13' },
  });
  req.on('upgrade', (res, socket) => {
    function frame(op, payload) {
      const len = payload.length;
      let h;
      if (len < 126) { h = Buffer.alloc(2); h[1] = len; }
      else if (len < 65536) { h = Buffer.alloc(4); h[1] = 126; h.writeUInt16BE(len, 2); }
      else { h = Buffer.alloc(10); h[1] = 127; h.writeUInt32BE(Math.floor(len/4294967296),2); h.writeUInt32BE(len%4294967296,6); }
      h[0] = 0x80 | op; h[1] |= 0x80;
      const mask = crypto.randomBytes(4);
      const m = Buffer.from(payload);
      for (let i = 0; i < m.length; i++) m[i] ^= mask[i & 3];
      socket.write(Buffer.concat([h, mask, m]));
    }
    let buf = Buffer.alloc(0);
    socket.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      while (buf.length >= 2) {
        const op = buf[0] & 0x0f;
        let len = buf[1] & 0x7f, off = 2;
        if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
        else if (len === 127) { if (buf.length < 10) return; len = buf.readUInt32BE(2) * 4294967296 + buf.readUInt32BE(6); off = 10; }
        if (buf.length < off + len) return;
        const payload = buf.subarray(off, off + len);
        buf = buf.subarray(off + len);
        if (op === 1) {
          const msg = JSON.parse(payload.toString());
          if (msg.type === 'log') console.error('  [ffmpeg]', msg.message.slice(0, 160));
          else if (msg.type === 'stats') console.error('  [stats]', msg.fps.toFixed(1), 'fps', msg.bitrate, 'sent', (msg.bytesIn/1024|0)+'KB');
          else if (msg.type === 'stopped') { console.log('  -> stopped', msg.code); socket.end(); process.exit(0); }
          else console.log('  <-', JSON.stringify(msg).slice(0, 200));
        }
        if (op === 8) { socket.end(); process.exit(0); }
      }
    });
    cb({ socket, frame });
  });
  req.end();
}

connect(({ socket, frame }) => {
  socket.setNoDelay(true);
  frame(0x1, Buffer.from(JSON.stringify({
    type: 'start', mode: 'youtube', streamKey: key, ingest,
    preset: '720p30', fps: 30, height: 720, container: 'webm',
  })));

  setTimeout(() => {
    const data = fs.readFileSync(file);
    const chunk = Math.ceil(data.length / (SECONDS * 2)); // ~2 chunks/s, comme MediaRecorder
    let i = 0;
    const t = setInterval(() => {
      if (i >= data.length) { clearInterval(t); frame(0x1, Buffer.from(JSON.stringify({ type: 'stop' }))); return; }
      frame(0x2, data.subarray(i, i + chunk));
      i += chunk;
    }, 500);
  }, 600);
});
